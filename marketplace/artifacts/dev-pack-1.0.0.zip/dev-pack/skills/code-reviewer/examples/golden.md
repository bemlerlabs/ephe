# Golden Example

## Trace 1 (Standard)
1. Input: /review - here is a simple Python function: def add(a, b): return a + b
2. ToolCall: {"name": "read_file", "arguments": {"path": "tests/test_example.py", "offset": 1, "limit": 50}}
3. Observation: Summary
4. Final: Summary (supported by tool output).

## Trace 2 (Edge case: error path)
1. Input: /review - here is a simple Python function: def add(a, b): return a + b (source/path not found)
2. ToolCall: {"name": "read_file", "arguments": {"path": "tests/test_example.py", "offset": 1, "limit": 50}}
3. Observation: [tool-error] entry not found
4. Final: Report the error honestly; next step: Summary.
